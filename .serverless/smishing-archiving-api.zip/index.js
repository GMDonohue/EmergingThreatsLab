// API accepts images, OCR to parse URL and return whois data
// Return data to user, and save to DynamoDb

// TODO: Add functionality to send data to DynamoDb
// TODO: API response to user