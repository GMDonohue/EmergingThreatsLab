declare module 'whois' {
    const whois: any;
    export default whois;
}
